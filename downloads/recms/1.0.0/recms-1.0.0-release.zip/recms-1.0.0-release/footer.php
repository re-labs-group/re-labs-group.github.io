
<hr>

<p>(c) <?php include "./assets/year.php"; ?> - <?php include "./assets/site-name.php"; ?></p>