<style>


body {
    margin: 0;
    padding: 40px 20px;
    background: #f5f7fb;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    color: #1d2327;
    display: flex;
    justify-content: center;
}

/* CARD */
.card {
    width: 100%;
    max-width: 800px;
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.08);
    overflow: hidden;
}

/* CONTENT WRAPPER */
.card-footer {
    padding: 30px;
}

/* TITLE */
.card h2 {
    margin: 0 0 20px 0;
    font-size: 28px;
    line-height: 1.3;
    color: #1d2327;
}

/* TEXT */
.card p {
    font-size: 16px;
    line-height: 1.7;
    color: #3c434a;
    margin: 0;
    white-space: pre-wrap; /* zachová nové řádky */
}

/* extra spacing for nested <p> (protože máš divný double <p>) */
.card p p {
    margin: 0;
}

/* optional subtle divider */
.card-footer::after {
    content: "";
    display: block;
    margin-top: 20px;
    height: 1px;
    background: #e2e4e7;
    opacity: 0.7;
}
</style>



<?php
        
        include "mysql/db.php";
        
        
       $post_id = $_GET['id'];

        
        
        $dotazProVypisPrispevku = "SELECT * FROM `posts` WHERE `post_id` = '$post_id'";

        $vysledkyVypisuProView = mysqli_query($connection,$dotazProVypisPrispevku);
        
        
        $row = mysqli_fetch_assoc($vysledkyVypisuProView);
        
     echo "<article class='card'>";
     
     echo "<div class='card-footer'>";
     
    echo "<h2>" . $row['PostName'] . "</h2>";
   echo "<p>" . $row['PostContect'] . "</p>";
    

    
    echo "</div>";

echo "<center><button onclick='window.print()'>Print page</button>  <button onclick='history.back()'>Go back</button></center>";

        echo "</article>";
        
        echo "<br>";



?>