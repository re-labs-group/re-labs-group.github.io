<style>
body {
    background: #f6f7f7;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

form {
    background: #fff;
    padding: 24px;
    border-radius: 6px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.12);
    width: 500px;
}

input[type="text"] {
    width: 100%;
    padding: 10px;
    font-size: 14px;
    border: 1px solid #dcdcde;
    border-radius: 4px;
    margin-bottom: 12px;
    box-sizing: border-box;
    background: #fbfbfb;
}

textarea {
    width: 100%;
    padding: 10px;
    font-size: 14px;
    border: 1px solid #dcdcde;
    border-radius: 4px;
    background: #fbfbfb;
    box-sizing: border-box;
    resize: vertical;
    margin-bottom: 12px;
}

input[type="text"]:focus,
textarea:focus {
    border-color: #2271b1;
    outline: none;
    background: #fff;
    box-shadow: 0 0 0 1px #2271b1;
}

button {
    background: #2271b1;
    color: white;
    border: none;
    padding: 10px 16px;
    border-radius: 4px;
    cursor: pointer;
    font-size: 14px;
    width: 100%;
}

button:hover {
    background: #135e96;
}
</style>