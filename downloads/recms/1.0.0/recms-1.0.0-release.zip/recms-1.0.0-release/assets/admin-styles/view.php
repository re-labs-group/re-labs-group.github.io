<style>
body {
    background: #f0f2f5;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    margin: 0;
    padding: 40px 20px;
}

.card {
    background: #fff;
    max-width: 700px;
    margin: 0 auto 20px auto;
    border-radius: 8px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.12);
    transition: 0.2s ease;
    overflow: hidden;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
}

.card-footer {
    padding: 22px;
}

.card h2 {
    margin: 0 0 10px 0;
    font-size: 24px;
    color: #1d2327;
}

.card p {
    margin: 0 0 16px 0;
    color: #646970;
    font-size: 14px;
}

.card a {
    display: inline-block;
    text-decoration: none;
    background: #2271b1;
    color: white;
    padding: 10px 14px;
    border-radius: 4px;
    font-size: 14px;
    transition: background 0.2s ease;
}

.card a:hover {
    background: #135e96;
}
</style>