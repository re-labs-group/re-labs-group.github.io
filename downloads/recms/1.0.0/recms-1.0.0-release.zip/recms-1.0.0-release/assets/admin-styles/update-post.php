<style>
body {
    background: #f0f2f5;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    color: #1d2327;
}

.message-box {
    background: #fff;
    padding: 30px;
    width: 340px;
    text-align: center;
    border-radius: 8px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.12);
}

.message-box p {
    margin: 0 0 20px 0;
    font-size: 16px;
}

.message-box a {
    display: inline-block;
    text-decoration: none;
    background: #2271b1;
    color: white;
    padding: 10px 16px;
    border-radius: 4px;
    font-size: 14px;
    transition: background 0.2s ease;
}

.message-box a:hover {
    background: #135e96;
}
</style>
