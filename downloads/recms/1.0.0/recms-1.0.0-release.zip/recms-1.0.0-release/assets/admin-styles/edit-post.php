<style>
body {
    background: #f0f2f5;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    margin: 0;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
}

form {
    background: #fff;
    width: 600px;
    padding: 28px;
    border-radius: 8px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.12);
}

label {
    display: block;
    margin-bottom: 8px;
    color: #1d2327;
    font-size: 14px;
    font-weight: 600;
}

input[type="text"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #dcdcde;
    border-radius: 4px;
    background: #fbfbfb;
    font-size: 15px;
    box-sizing: border-box;
}

textarea {
    width: 100%;
    padding: 12px;
    border: 1px solid #dcdcde;
    border-radius: 4px;
    background: #fbfbfb;
    font-size: 15px;
    resize: vertical;
    box-sizing: border-box;
    min-height: 220px;
}

input[type="text"]:focus,
textarea:focus {
    border-color: #2271b1;
    background: #fff;
    outline: none;
    box-shadow: 0 0 0 1px #2271b1;
}

button {
    width: 100%;
    background: #2271b1;
    color: white;
    border: none;
    padding: 12px;
    border-radius: 4px;
    font-size: 14px;
    cursor: pointer;
    transition: background 0.2s ease;
}

button:hover {
    background: #135e96;
}
</style>