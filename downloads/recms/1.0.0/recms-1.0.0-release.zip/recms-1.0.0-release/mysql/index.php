<?php

echo "Access denied";

?>