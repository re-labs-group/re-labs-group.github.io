<?php

session_start();

include "../mysql/db.php";

?>


<?php
        
    if($_SESSION["is_logged_in"] == True) {
    
        $user_id = $_SESSION["user_id"];
        $nazevPrispevku = $_POST["nazev-prispevku"];
        $obsahOrispevku = $_POST["obsah-prispevku"];
        
        $insertPost = "
INSERT INTO posts (author, PostName, PostContect)
VALUES ('$user_id', '$nazevPrispevku', '$obsahOrispevku')
";

    $result = mysqli_query($connection, $insertPost);
    
        if($result != True) {
    
        echo "ERROR";
    
         } else {
               header("Location: index.php");
            }
    } else {
    
    header("Location: login.php");
    
    }
        
?>