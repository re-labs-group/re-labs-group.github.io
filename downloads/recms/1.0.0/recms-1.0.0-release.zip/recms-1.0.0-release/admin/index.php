<?php

session_start();

include "../mysql/db.php";

?>


<?php
        
    if($_SESSION["is_logged_in"] != True) {
    
    header("Location: login.php");
    exit; 
        
        
    } else {
    
    $prihlasen = "ok";
        
        
    }
        
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin panel</title>
    
    
    <style>

  
    </style>


</head>

<body>
<?php 
if($prihlasen = "ok") {
   
   echo "<a href='post.php?do=view'><img src='../assets/btns/viewMyPosts.png'></a>";
   echo "<a href='post.php?do=new'><img src='../assets/btns/new.png'></a>";
   echo "<a href='post.php?do=edit'><img src='../assets/btns/edit.png'></a>";
   echo "<a href='post.php?do=delete'><img src='../assets/btns/delete.png'></a>";
   echo "<a href='resetPswrd.php'><img src='../assets/btns/reset.png'></a>";
   echo "<a href='logout.php'><img src='../assets/btns/logout.png'></a>";
   
        
    }
    

?>
    
</body>
</html>