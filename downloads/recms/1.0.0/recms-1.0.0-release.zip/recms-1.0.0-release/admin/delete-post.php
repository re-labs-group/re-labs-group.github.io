<?php

session_start();

include "../mysql/db.php";

?>


<?php
        
    if($_SESSION["is_logged_in"] == True) {
    
        
        $idPrispevku = $_POST["post_id"];
     
        $queryDeletePost = "DELETE FROM posts WHERE post_id = '$idPrispevku'";
        

    $result = mysqli_query($connection, $queryDeletePost);
    
        if($result != True) {
    
        echo "ERROR";
    
         } else {
               header("Location: index.php");
            }
    } else {
    
    header("Location: login.php");
    
    }
        
?>