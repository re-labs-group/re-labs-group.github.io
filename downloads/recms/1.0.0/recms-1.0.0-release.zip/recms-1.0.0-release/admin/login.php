<?php

session_start();

include "../mysql/db.php";

?>

<?php

if(isset($_POST["submit"])) {

$username = $_POST["username"];
$password = $_POST["password"];

$hashed_password = hash('sha256', $password);


$DotazProPrihlaseni = "SELECT user_id, username FROM users WHERE username = '$username' AND password_hash = '$hashed_password';";

$vysledekDotazu = mysqli_query($connection,$DotazProPrihlaseni);

$pole_row = mysqli_fetch_assoc($vysledekDotazu);


        if($pole_row) {
        
        
        
        $_SESSION["is_logged_in"] = True;
        $_SESSION["user_id"] = $pole_row["user_id"];
        
        
            header("Location: index.php");
            exit;
        
        } else {
        
        die("<h3>Wrong password or username !</h3> <br> <a href='login.php'>Return back</a>");
        
        }
        
        
        
        
        
}







?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    
    
    <style>
body {
    background: #f0f0f1;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

form {
    background: #fff;
    padding: 26px 24px;
    border-radius: 6px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.13);
    width: 320px;
}

label {
    display: block;
    margin-top: 12px;
    margin-bottom: 6px;
    font-size: 14px;
    color: #23282d;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 8px 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    background: #fbfbfb;
    box-sizing: border-box;
}

input[type="text"]:focus,
input[type="password"]:focus {
    border-color: #2271b1;
    box-shadow: 0 0 0 1px #2271b1;
    outline: none;
    background: #fff;
}

input[type="submit"] {
    margin-top: 18px;
    width: 100%;
    background: #2271b1;
    color: white;
    border: none;
    padding: 10px;
    font-size: 14px;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background: #135e96;
}
</style>


</head>

<body>


<form action="login.php" method="POST">

    <center><img src="../assets/logo.svg"></center>

    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

<br>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

<br>

    <input type="submit" name="submit" value="Login">


</form>

    
</body>
</html>