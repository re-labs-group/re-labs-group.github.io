<?php

session_start();

include "../mysql/db.php";

?>


<?php
        
    if($_SESSION["is_logged_in"] == True) {
    
        $prihlaseniOK = $_SESSION["is_logged_in"];
        
    
    
    } else {
    
    header("Location: login.php");
    exit;
    }
        
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Processor</title>
</head>

<body>

<?php

if($prihlaseniOK == True) {

if(isset($_GET["do"])) {


        //new post

        if($_GET["do"] == "new") {

include "../assets/admin-styles/new.php";

            echo "<form action='submit-new-post.php' method='POST'>";
  echo "<input type='text' name='nazev-prispevku' placeholder='Post name'>";
  echo "<br>";
  echo "<textarea name='obsah-prispevku' rows='10' cols='50' placeholder='Write...'></textarea>";
 echo "<br>";
  echo "<button type='submit'>Create post</button>";
echo "</form>";


        }


            //edit post
        if($_GET["do"] == "edit") {

                        include "../assets/admin-styles/delete.php";
        
        $queryProziskaniIDproEdit = "SELECT post_id FROM posts";
        $resultIDproEdit = mysqli_query($connection, $queryProziskaniIDproEdit);

        
        
    

        echo "<form action='edit-post.php' method='POST'>";
        
        
        echo "<label for='post_id'>Post ID: </label>";

echo "<select name='post_id'>";


    while($rowIDproEdit = mysqli_fetch_assoc($resultIDproEdit)) {

    $idProSelect = $rowIDproEdit["post_id"];

    echo "<option value='$idProSelect'>$idProSelect</option>";
}



echo "</select>";


        echo "<br>";
         echo "<button type='submit'>Edit this post</button>";
        echo "</form>";
        
        



        }
        
        
        
        // view post
        
        if($_GET["do"] == "view") {

        include "../assets/admin-styles/view.php";
        
        $dotazProVypisPrispevku = "SELECT * FROM `posts` ORDER BY `post_id` ASC";

        $vysledkyVypisuProView = mysqli_query($connection,$dotazProVypisPrispevku);
        
        
        while($row = mysqli_fetch_assoc($vysledkyVypisuProView)) {
        
     echo "<article class='card'>";
     
     echo "<div class='card-footer'>";
     
    echo "<h2>" . $row['PostName'] . "</h2>";
    echo "<p>post ID: " . $row['post_id'] . "</p>";
    
    
    echo "<a href='";
    echo "../post.php?id=";
    echo $row['post_id'];
    echo "'>View complete post</a>";
    
    echo "</div>";
        echo "</article>";
        
        echo "<br>";
        
                    }
        
        

        }
        
        
        //delete post
        if($_GET["do"] == "delete") {
        
        include "../assets/admin-styles/delete.php";
        
        $queryProSmazani = "SELECT post_id FROM posts";
        $resultSmazaniPostu = mysqli_query($connection, $queryProSmazani);

        
        
    

        echo "<form action='delete-post.php' method='POST'>";
        
        
        echo "<label for='post_id'>Post ID: </label>";

echo "<select name='post_id'>";


    while($rowIDproSmazani = mysqli_fetch_assoc($resultSmazaniPostu)) {

    $idProSelect = $rowIDproSmazani["post_id"];

    echo "<option value='$idProSelect'>$idProSelect</option>";
}



echo "</select>";


        echo "<br>";
         echo "<button type='submit'>Delete post</button>";
        echo "</form>";

        }


} else {

echo "Action was not selected";

}

}
?>

    
</body>
</html>