

<?php

if(isset($_POST["submit"])) {

$username = $_POST["username"];
$password = $_POST["password"];
$siteName = $_POST["site-name"];

$dbHost = $_POST["dbhost"];
$dbName = $_POST["dbname"];
$dbUser = $_POST["dbuser"];
$dbPass = $_POST["dbpass"];
        
// connection to mysql
$conn = mysqli_connect($dbHost, $dbUser, $dbPass);

if (!$conn) {
    die("Connection error: " . mysqli_connect_error());
}    


// creating db
if (!mysqli_query($conn, "CREATE DATABASE IF NOT EXISTS $dbName")) {
    die("Error with creating database: " . mysqli_error($conn));
}

// select DB
mysqli_select_db($conn, $dbName);


// table users
$sql = "
CREATE TABLE IF NOT EXISTS users (
  user_id INT(11) NOT NULL AUTO_INCREMENT,
  username VARCHAR(30) NOT NULL,
  password_hash VARCHAR(70) NOT NULL,
  Name VARCHAR(20) NOT NULL,
  registered_at DATETIME NOT NULL,
  role VARCHAR(20) NOT NULL,
  PRIMARY KEY (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
";

if (!mysqli_query($conn, $sql)) {
    die("Error with creating table Users: " . mysqli_error($conn));
}





// table posts
$sqlPosts = "
CREATE TABLE IF NOT EXISTS posts (
  post_id INT(11) NOT NULL AUTO_INCREMENT,
  author VARCHAR(30) NOT NULL,
  PostName VARCHAR(50) NOT NULL,
  PostContect VARCHAR(3000) NOT NULL,
  Created_at DATETIME NOT NULL,
  PRIMARY KEY (post_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
";

if (!mysqli_query($conn, $sqlPosts)) {
    die("Error with creating table Posts: " . mysqli_error($conn));
}







// hash hesla (SHA-256)
$passwordHash = hash("sha256", $password);

// čas registrace
$registeredAt = date("Y-m-d H:i:s");

// role
$role = "admin";

// escapování názvu (aby se nerozbilo SQL)
$usernameEsc = mysqli_real_escape_string($conn, $username);
$nameEsc = mysqli_real_escape_string($conn, $username);

// vložení admin uživatele
$insertUser = "
INSERT INTO users (username, password_hash, Name, registered_at, role)
VALUES ('$usernameEsc', '$passwordHash', '$nameEsc', '$registeredAt', '$role')
";

if (!mysqli_query($conn, $insertUser)) {
    die("Error creating admin user: " . mysqli_error($conn));
}




// content db.php
$dbFileContent = "<?php\n\n";
$dbFileContent .= "\$connection = mysqli_connect(\"$dbHost\",\"$dbUser\",\"$dbPass\",\"$dbName\");\n\n";
$dbFileContent .= "?>";

if (!file_put_contents("../mysql/db.php", $dbFileContent)) {
    die("Error creating db.php file");

}

$siteNameContent = $siteName;

if (!file_put_contents("../assets/site-name.php", $siteNameContent)) {
    die("Error creating db.php file");

}


$ok = "ok";

    
        
}







?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Install reCMS</title>
    
    
    <style>
body {
    background: #f0f0f1;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    display: flex;
    justify-content: center;
    align-items: center;
    height: 100vh;
    margin: 0;
}

form {
    background: #fff;
    padding: 26px 24px;
    border-radius: 6px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.13);
    width: 320px;
}

label {
    display: block;
    margin-top: 12px;
    margin-bottom: 6px;
    font-size: 14px;
    color: #23282d;
}

input[type="text"],
input[type="password"] {
    width: 100%;
    padding: 8px 10px;
    border: 1px solid #ddd;
    border-radius: 4px;
    font-size: 14px;
    background: #fbfbfb;
    box-sizing: border-box;
}

input[type="text"]:focus,
input[type="password"]:focus {
    border-color: #2271b1;
    box-shadow: 0 0 0 1px #2271b1;
    outline: none;
    background: #fff;
}

input[type="submit"] {
    margin-top: 18px;
    width: 100%;
    background: #2271b1;
    color: white;
    border: none;
    padding: 10px;
    font-size: 14px;
    border-radius: 4px;
    cursor: pointer;
}

input[type="submit"]:hover {
    background: #135e96;
}
</style>


</head>

<body>


<form action="install.php" method="POST">

    <center><img src="../assets/logo.svg"></center>


    <label for="site-name"><b>Your Site name</b></label>
    <input type="text" placeholder="Enter your site name" name="site-name" required>

<br>

    <label for="username"><b>Username</b></label>
    <input type="text" placeholder="Enter Username" name="username" required>

<br>

    <label for="password"><b>Password</b></label>
    <input type="password" placeholder="Enter Password" name="password" required>

<br>

<!--  DB   -->

    <label for="dbhost"><b>Database host</b></label>
    <input type="text" placeholder="localhost" name="dbhost" required>

<br>


    <label for="dbname"><b>Database name</b></label>
    <input type="text" placeholder="myDB1" name="dbname" required>

<br>

    <label for="dbuser"><b>Database username</b></label>
    <input type="text" placeholder="root" name="dbuser" required>

<br>

    <label for="dbpass"><b>Database password</b></label>
    <input type="text" placeholder="root" name="dbpass">

<br>




    <input type="submit" name="submit" value="Register AND Install">

<?php
if (isset($ok)) {

	if ($ok == "ok") {
		echo "reCMS was successfully installed. Please remove install.php";
	}


}

?>

</form>

    
</body>
</html>