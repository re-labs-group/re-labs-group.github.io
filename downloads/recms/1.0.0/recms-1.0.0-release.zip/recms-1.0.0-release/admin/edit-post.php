<?php

session_start();

include "../mysql/db.php";

?>


<?php
        
    if($_SESSION["is_logged_in"] == True) {
    
        
        $post_id = $_POST["post_id"];
     
        $query = "SELECT * FROM posts WHERE post_id = $post_id";
        

    $result = mysqli_query($connection, $query);
    $row = mysqli_fetch_assoc($result);
    $title = $row["PostName"];
$content = $row["PostContect"];
    
        if($result != True) {
    
        echo "ERROR";
    
         } else {
               //header("Location: index.php");
            }
    } else {
    
    header("Location: login.php");
    exit;
    }
        
?>

<?php include "../assets/admin-styles/edit-post.php"; ?>

<form action="update-post.php" method="POST">

    <input type="hidden" name="post_id" value="<?php echo $post_id; ?>">

    <label>Title</label>
    <br>

    <input type="text" name="post_title" value="<?php echo $title; ?>">

    <br><br>

    <label>Content</label>
    <br>

    <textarea name="post_content" rows="10" cols="50"><?php echo $content; ?></textarea>

    <br><br>

    <button type="submit">Update Post</button>

</form>