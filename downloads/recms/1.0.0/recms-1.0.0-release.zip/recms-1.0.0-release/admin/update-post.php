<?php

include "../mysql/db.php";

if(isset($_POST["post_id"])) {

    $post_id = (int) $_POST["post_id"];

    $title = mysqli_real_escape_string($connection, $_POST["post_title"]);

    $content = mysqli_real_escape_string($connection, $_POST["post_content"]);

    $query = "UPDATE posts 
              SET PostName = '$title',
                  PostContect = '$content'
              WHERE post_id = $post_id";

    mysqli_query($connection, $query);

    include "../assets/admin-styles/edit-post.php";
echo "<div class='message-box'>";
    echo "<p>✅ Post updated.</p>";
    echo "<a href='index.php'>Return back</a>";
    echo "</div>";
}

?>