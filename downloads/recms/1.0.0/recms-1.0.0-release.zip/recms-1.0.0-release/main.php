<?php
        
    include "mysql/db.php";

        $dotazProVypisAutora = "SELECT username FROM `users` WHERE `post_id` = ";




        
        $dotazProVypisPrispevku = "SELECT * FROM `posts` ORDER BY `post_id` ASC";

        $vysledkyVypisuProView = mysqli_query($connection,$dotazProVypisPrispevku);
        
        
        while($row = mysqli_fetch_assoc($vysledkyVypisuProView)) {
        
        $Aname = $row['author'];
            $dotazProVypisAutora = "SELECT username FROM `users` WHERE `user_id` = '$Aname'";
        
        $JmenoResult = mysqli_query($connection,$dotazProVypisAutora);
        $rowJmeno = mysqli_fetch_assoc($JmenoResult);
        
     echo "<article class='card'>";
     
     echo "<div class='card-footer'>";
     
    echo "<h2>" . $row['PostName'] . "</h2>";
    

    
    
    echo "<p><b>Author:</b> " . $rowJmeno['username'] . "</p>";
    
    echo "<p><b>Preview: </b></p>";
    echo "<p>";
    echo mb_substr($row['PostContect'], 0, 40, "UTF-8") . "...";
    echo "</p>";
    
    echo "<a href='";
    echo "./post.php?id=";
    echo $row['post_id'];
    echo "'>View complete post</a>";
    
    echo "</div>";
        echo "</article>";
        
        echo "<br>";

    }
?>