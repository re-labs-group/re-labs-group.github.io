<style>
/* ===== BASE ===== */
body {
    margin: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
    background: #f5f7fb;
    color: #1d2327;
    line-height: 1.6;
}

/* ===== HEADER ===== */
header {
    text-align: center;
    padding: 40px 20px 20px;
    background: linear-gradient(135deg, #2271b1, #135e96);
    color: white;
}

header h1 {
    margin: 0;
    font-size: 36px;
    letter-spacing: 1px;
}

header hr {
    border: none;
    height: 1px;
    background: rgba(255,255,255,0.3);
    margin-top: 20px;
}

/* ===== MAIN LAYOUT ===== */
main {
    max-width: 1000px;
    margin: 40px auto;
    padding: 0 20px;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
}

/* ===== CARD ===== */
.card {
    background: white;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    overflow: hidden;
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.card:hover {
    transform: translateY(-4px);
    box-shadow: 0 6px 18px rgba(0,0,0,0.12);
}

.card-footer {
    padding: 20px;
}

.card h2 {
    margin-top: 0;
    font-size: 20px;
    color: #1d2327;
}

.card p {
    margin: 6px 0;
    font-size: 14px;
    color: #50575e;
}

/* preview text */
.card p:last-of-type {
    color: #646970;
}

/* ===== LINK BUTTON ===== */
.card a {
    display: inline-block;
    margin-top: 14px;
    padding: 10px 14px;
    background: #2271b1;
    color: white;
    text-decoration: none;
    border-radius: 6px;
    font-size: 14px;
    transition: background 0.2s ease;
}

.card a:hover {
    background: #135e96;
}

/* ===== FOOTER ===== */
footer {
    text-align: center;
    padding: 30px 20px;
    color: #646970;
}

footer hr {
    border: none;
    height: 1px;
    background: #dcdcde;
    margin-bottom: 20px;
}

/* ===== RESPONSIVE ===== */
@media (max-width: 600px) {
    header h1 {
        font-size: 28px;
    }

    main {
        grid-template-columns: 1fr;
    }
}
</style>