//---------------------------------------------
//                                            -
//               SafeRM 1.0.0                 -
//              by Matěj Truxa                -
//                                            -
//---------------------------------------------


#include <stdio.h>
#include <unistd.h>
#include <string.h>

//vars
char *filename1;

int main(int argc, char *argv[]) {

    if (argc < 2) {
        printf("Error! Usage: saferm <filename>\n");
        return 1;
    }

    filename1 = argv[1];

    char YorN;

    printf("Are you really sure to delete file %s ? (Y/N): ", filename1);
    scanf(" %c", &YorN);  // space before %c is important

    if (YorN == 'Y' || YorN == 'y') {

        char *arg[] = {"sudo", "rm", filename1, NULL};
        execvp("sudo", arg);

    } else {
        printf("Removing terminated.\n");
    }

    return 0;
}
